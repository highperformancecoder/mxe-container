IF db_id('soci_test') IS NULL BEGIN CREATE DATABASE [soci_test] END;
