# Example of using SOCI with CMake

For this example, we assume, that the whole SOCI repository is located in this repository.
